﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AccountApp;
namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestBalance()
        {
            CheckingAccount a = new CheckingAccount(5000, 200);
            Assert.AreEqual(5000, a.AccBalance);
            //nunit
        }
        [TestMethod]
        public void TestFee()
        {
            CheckingAccount b = new CheckingAccount(5000, 200);
            Assert.AreEqual(200, b.Fee);
            //nunit
        }
        [TestMethod]
        public void TestCredit()
        {
            CheckingAccount c = new CheckingAccount(5000, 200);
            c.Credit(300);
            Assert.AreEqual(5100, c.AccBalance);
            //nunit
        }
        [TestMethod]
        public void TestDebit()
        {
            CheckingAccount d = new CheckingAccount(5000, 200);
            d.Debit(300);
            Assert.AreEqual(4500, d.AccBalance);
            //nunit
        }

        [TestMethod]
        public void TestInterest()
        {
            SavingsAccount e = new SavingsAccount(5000, 2.5m);
            decimal temp = e.CalculateInterest();
            e.Credit(e.CalculateInterest());
            Assert.AreEqual(17500, e.AccBalance);
            //nunit
        }
    }
}
