﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp
{
    public class SavingsAccount : Account
    {
        private decimal intRate;
        public SavingsAccount(decimal accBal, decimal interestRate): base(accBal)
        {
            AccBalance = accBal;
            intRate = interestRate;
        }

        public decimal CalculateInterest()
        {
            decimal intAmount = (AccBalance * intRate);
            return intAmount;
        }


    }
}
