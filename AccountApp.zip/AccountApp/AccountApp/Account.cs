﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp
{
    public class Account
    {
        private decimal accBalance;

        public Account(decimal accBal)
        {
            AccBalance = accBal;
        }

        public decimal AccBalance
        {
            get
            {
                return accBalance;
            }
            set
            {
                if(value < 0)
                {  
                    throw new ArgumentOutOfRangeException(nameof(value),value,$"{nameof(AccBalance)} must be >= 0");
                }

                accBalance = value;
            }
        }

        public virtual void Credit(decimal valuex)
        {
            if(valuex > 0)
            {
                AccBalance += valuex;
            }
            else
            {
                throw new ArgumentOutOfRangeException(nameof(valuex), valuex, $"{nameof(AccBalance)} must be >= 0");
            }
        }

        public virtual void Debit(decimal valuex)
        {
            if(valuex > 0 && valuex <= AccBalance)
            {
                AccBalance -= valuex;
            }
            else
            {
                Console.WriteLine("Debit amount exceeded account balance.");
                
            }
        }
    }
}
