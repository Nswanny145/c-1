﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccountApp 
{
    
    public class CheckingAccount : Account
    {
        private decimal feePer;
        public CheckingAccount(decimal accBal, decimal feeAmount) : base(accBal)
        {
            AccBalance = accBal;
            Fee = feeAmount;
        }

        public decimal Fee
        {
            get
            {
                return feePer;
            }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value), value, $"{nameof(AccBalance)} must be >= 0");
                }
                else
                {
                    feePer = value;
                }
            }
        }

        public override void Credit(decimal v)
        {
            base.Credit(v - Fee);
            
        }

        public override void Debit(decimal va)
        {
            if(va > AccBalance)
            {
                Console.WriteLine("Value bigger than Account Balance");
            }
            else
            {
                base.Debit(va + Fee);
            }
        }
    }
}
